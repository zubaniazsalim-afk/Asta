# Assignment 3: Maze Escape

Student ID: **YOUR_STUDENT_ID - fill in before submission**  
Name: **YOUR_NAME**  
Group: **YOUR_GROUP**  
Included demonstration maze: **5 x 5, copied from examples/small**

## Important: personal variant and own work

This is an AI-assisted reference implementation for study and revision. It is not ready for unchanged submission. The assignment requires your own changes, understanding of every line, an honest AI disclosure, and your own explanations during the defense. Review, modify and test the code yourself, and rewrite the explanations in your own words.

No student ID was supplied. No personal ID has been invented. The included data/walls.txt and data/slides.txt are the starter's public small example, not a personal variant. The output and picture below belong to that example.

From the maze-escape folder, with JDK 17 or newer:

```text
java tools/MakeVariant.java YOUR_STUDENT_ID data
javac -d out src/*.java
java -cp out Main
java tools/Check.java
java -cp out Bench
```

Replace YOUR_STUDENT_ID with the exact ID from Moodle, keeping leading zeros. Do not run the generator with the literal placeholder. After generating your variant, update the identity fields, maze size and 13 output lines below. Main regenerates output/maze.html and output/maze.png. Open output/maze.html in a browser to walk through the maze, display the path, zones and slides, or play the construction animation.

## Program output

Demonstration only: examples/small, also copied into data. Kruskal and Prim both give MST cost 8717.

```text
Broken: 24
Kept: 16
Last broken wall: 38
MST cost: 8717
Heaviest broken wall: 793
Path length: 10
DFS visited: 25
Dead ends: 6
Zones: 12
Largest zone: 4
Is DAG: 0
Flow stages: 7
Fastest route cost: 19
```

![Demonstration maze](output/maze.png)

The picture uses the file-order maze from Mission 1, not the cheapest maze from Mission 2. The red line is the route from the green start to the blue exit.

## How the code works

- DisjointSet.java stores a parent and size for each set. Maze.java uses it for file-order wall breaking and sorted Kruskal; Prim uses a standard priority queue of wall indexes.
- Escape.java keeps the current DFS path in an array stack and remembers which direction to try next at each cell. It stops immediately when the exit is visited.
- Zones.java records DFS finishing order with an explicit stack, labels components on the reversed slides, then processes the component graph in increasing zone order.
- Main, Input, Graphs, Render, Generator, Bench, Check and MakeVariant retain the starter behavior. Comments were removed from Java sources as requested; explanations are here. No external graph or DSU library is used.

## Questions

### Mission 0

find returns the root representing a cell's set. union joins different roots, puts the smaller tree under the larger one, and decreases the set count. Full path compression makes later searches shorter; together with union by size it gives amortized O(alpha(n)) operations.

### Mission 1

The full rectangular grid is connected. Each accepted wall joins two components without making a cycle, so joining n initially separate cells needs n - 1 walls, where n = R*C. The grid has R*(C-1) + C*(R-1) inner walls; subtracting R*C-1 leaves (R-1)*(C-1) kept walls.

### Mission 2

On the included demonstration, both Kruskal and Prim return 8717. Kruskal chooses the cheapest edge joining different components, while Prim chooses the cheapest edge leaving the visited part; both choices satisfy the MST cut property. The assignment's distinct weights also make the MST unique.

### Mission 3

The open passages form a connected graph without cycles, which is a tree. Two different simple paths between the same cells would create a cycle, so there is exactly one simple path. DFS uses arrays on the heap instead of recursive method calls, so a long path cannot overflow the Java call stack.

Directions are tried up, right, down, left. Each cell is marked on entry, including the start and exit; visited is counted only until the exit is reached. Dead ends are counted over the entire maze, including start and exit when their degree is one.

### Mission 4

The first pass records finishing times in the original slide graph. Starting from the last finished unassigned cell on the reversed graph reaches its whole component without crossing into an unassigned component, so each second-pass search labels exactly one zone. With no self-loops as guaranteed by the input, a directed cycle exists exactly when some zone contains more than one cell, so the graph is a DAG exactly when there are n zones.

### Mission 5

The second pass numbers zones in topological order: every slide between different zones goes from a smaller number to a larger one. All incoming results are therefore ready when a zone is processed; one relaxation pass computes shortest costs and longest chain lengths. Building the grouped zone edges and processing them takes O(n+m+z) time and space, where z is the number of zones.

Slides within a zone are ignored because moving inside a zone is free in this task. Parallel slides between two zones are kept: relaxing all of them automatically chooses their minimum cost, with the same result as storing one cheapest edge. Every zone starts with chain length one, so flow stages measures the longest chain anywhere, even outside the route from start to exit.

## AI use

OpenAI Codex (ChatGPT) was used to read the assignment and starter, generate the algorithm implementations and additional checks, run verification and benchmarks, and draft this README. This includes generated code and text, not just explanations or review. The implementation is based on the supplied starter; no external graph or DSU library or external solution code was used.

Student action required: review and change the implementation yourself, understand every submitted line, rewrite the report in your own words, and update this disclosure with your actual work. Do not claim this generated project is entirely your own work or submit it unchanged. The assignment limits AI to assistance and treats unchanged AI-generated submission or missing disclosure as academic dishonesty. AI tools are not allowed during the defense.

## Timing: Mission 7

Measured with the unchanged starter Bench, five runs per size. Values are milliseconds rounded by Bench; averages use the underlying unrounded durations.

Environment: Windows x64, Eclipse Temurin OpenJDK 17.0.20.1+1, default JVM options. Measured on 2026-10-24; other desktop activity was not controlled.

| Maze | Kruskal: five runs | Kruskal average | Prim: five runs | Prim average |
|---|---|---|---|---|
| 100 x 100 | 26, 11, 11, 18, 18 | 17 | 27, 6, 7, 6, 5 | 10 |
| 300 x 300 | 103, 85, 76, 83, 58 | 81 | 65, 59, 65, 57, 65 | 62 |
| 1000 x 1000 | 1152, 1159, 1153, 1318, 1128 | 1182 | 1708, 1699, 1770, 1796, 1718 | 1738 |

Both algorithms sort or maintain a priority queue, so their expected growth on grid graphs is O(n log n), since m is proportional to n. The measurements also include allocation, garbage collection and JVM warm-up, so individual runs and small-size ratios vary. These are measurements on this computer, not a guaranteed running time on another computer.

## Complexity

n is the number of cells, m the number of walls or slides, and z the number of zones. Space means auxiliary storage, including adjacency arrays built by the methods.

| Algorithm | Time | Space | Assumptions |
|---|---|---|---|
| DSU construction | O(n) | O(n) | Initially one set per cell |
| DSU find / union | O(alpha(n)) amortized | O(1) per call; O(n) DSU total | Union by size and path compression; iterative find |
| File-order maze | O(n + m alpha(n)) | O(n+m) | Full connected rectangular grid |
| Kruskal | O(n + m log m + m alpha(n)) | O(n+m) | Sort wall indexes; use own DSU |
| Prim | O(n + m log(m+1)) | O(n+m) | Lazy binary heap of edges; O(m log n) on a simple connected grid |
| Iterative DFS | O(n+m) | O(n+m) | Degree at most four; dead ends counted for every cell |
| Kosaraju | O(n+m) | O(n+m) | Two iterative passes; no self-loops for Main's DAG test |
| Zone route and flow stages | O(n+m+z) | O(m+z) | zoneOf supplied; zone numbers topological; parallel edges retained |

## Verification

- JDK 17 compilation succeeded. `java tools/Check.java`: all 15 DSU checks passed; tiny, small and dag each matched all 13 expected lines.
- `java -cp out Main` on the included demonstration produced the output above, with no Kruskal/Prim mismatch warning.
- Additional temporary verification passed: 200 random MST comparisons and SCC/zone-route cases, checked against independent reachability and all-pairs route calculations.
- Iterative DFS passed on a 1000 x 1000 snake maze; Kosaraju and zone routes passed on a directed chain of 1,000,000 cells. A single-cell maze also passed. These stress checks used a 2 GB maximum heap.
- The PNG was opened and visually inspected. The HTML was tested in headless Chrome: no JavaScript errors; all five overlays, reset and construction controls ran, and following the path reached the exit in 10 moves (the expected optimum).
- Bench completed all five runs at all three required sizes. Temporary stress and browser scripts are excluded from the compact project; the required DisjointSetTest and Check remain.

## Files and submission

The project keeps START_HERE.md, the assignment PDF, all starter sources, both tools, examples, data and output. Compiled classes, local JDK downloads and temporary verification files are excluded from the ZIP. No build system or additional library is needed.

Before submission:

1. Generate your personal data, fill in your identity, and replace the demonstration results and picture.
2. Make and understand your own changes; update the explanations and AI disclosure honestly.
3. Run Check and Main again. Confirm Kruskal and Prim agree and inspect the regenerated HTML and PNG.
4. Work on main in your own public GitHub repository and commit real progress after each mission, with at least seven meaningful commits as required. This ZIP does not fabricate a student development history or supply a public repository link.
5. Include data/walls.txt, data/slides.txt and output/maze.png, verify public access, and submit the repository link in Moodle before its deadline.
