import java.util.Arrays;

public class Escape {
    public record Result(int[] path, int visited, int deadEnds) {}

    public static Result escape(Input.Walls w, int[] broken) {
        int[][] graph = Graphs.open(w, broken);
        int n = w.cells();
        int deadEnds = 0;
        for (int[] neighbours : graph) if (neighbours.length == 1) deadEnds++;
        int[] parent = new int[n];
        Arrays.fill(parent, -1);
        int[] stack = new int[n];
        int[] direction = new int[n];
        int top = 0;
        int visited = 1;
        parent[0] = 0;
        while (top >= 0 && stack[top] != n - 1) {
            int cell = stack[top];
            if (direction[cell] == 4) {
                top--;
                continue;
            }
            int d = direction[cell]++;
            int next = switch (d) {
                case 0 -> cell - w.cols();
                case 1 -> cell + 1;
                case 2 -> cell + w.cols();
                default -> cell - 1;
            };
            boolean open = false;
            for (int neighbour : graph[cell]) if (neighbour == next) open = true;
            if (open && parent[next] == -1) {
                parent[next] = cell;
                stack[++top] = next;
                visited++;
            }
        }
        if (top < 0) return new Result(new int[0], visited, deadEnds);
        return new Result(Arrays.copyOf(stack, top + 1), visited, deadEnds);
    }
}
