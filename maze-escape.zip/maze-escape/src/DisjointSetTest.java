public class DisjointSetTest {

    static int failed = 0;

    static void check(boolean ok, String what) {
        System.out.println((ok ? "ok    " : "FAIL  ") + what);
        if (!ok) failed++;
    }

    public static void main(String[] args) {
        DisjointSet d = new DisjointSet(6);
        check(d.count() == 6, "6 sets at the start");
        check(!d.connected(0, 1), "0 and 1 are apart at the start");
        check(d.union(0, 1), "union(0, 1) joins two sets");
        check(d.connected(0, 1), "0 and 1 are together");
        check(!d.union(1, 0), "union(1, 0) again returns false");
        check(d.count() == 5, "5 sets after one union");
        d.union(2, 3); d.union(1, 3);
        check(d.connected(0, 2), "0 and 2 are together through 1 and 3");
        check(d.count() == 3, "3 sets: {0,1,2,3} {4} {5}");
        check(d.find(4) == 4 && d.find(5) == 5, "a single cell is its own root");

        check(!d.union(4, 4), "self union returns false");
        check(d.count() == 3, "self union keeps count");
        DisjointSet large = new DisjointSet(100000);
        for (int i = 1; i < 100000; i++) large.union(i - 1, i);
        check(large.count() == 1, "one set after a large chain");
        check(large.connected(0, 99999), "chain endpoints connected");
        check(!large.union(99999, 0), "repeated chain union returns false");
        DisjointSet empty = new DisjointSet(0);
        check(empty.count() == 0, "empty DSU has zero sets");

        System.out.println(failed == 0 ? "All checks passed." : failed + " checks failed.");
    }
}
