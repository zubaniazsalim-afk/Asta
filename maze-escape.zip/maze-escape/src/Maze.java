import java.util.*;

public class Maze {
    public static int[] breakWalls(Input.Walls w) {
        DisjointSet sets = new DisjointSet(w.cells());
        int[] broken = new int[w.count()];
        int count = 0;
        for (int i = 0; i < w.count(); i++) {
            if (sets.union(w.a()[i], w.b()[i])) broken[count++] = i;
        }
        return Arrays.copyOf(broken, count);
    }

    public static int[] cheapestMaze(Input.Walls w) {
        Integer[] order = new Integer[w.count()];
        for (int i = 0; i < order.length; i++) order[i] = i;
        Arrays.sort(order, Comparator.comparingInt(i -> w.cost()[i]));
        DisjointSet sets = new DisjointSet(w.cells());
        int[] broken = new int[w.count()];
        int count = 0;
        for (int i : order) {
            if (sets.union(w.a()[i], w.b()[i])) broken[count++] = i;
            if (sets.count() == 1) break;
        }
        return Arrays.copyOf(broken, count);
    }

    public static long primCost(Input.Walls w) {
        int n = w.cells();
        int[] degree = new int[n];
        for (int i = 0; i < w.count(); i++) {
            degree[w.a()[i]]++;
            degree[w.b()[i]]++;
        }
        int[][] edges = new int[n][];
        for (int i = 0; i < n; i++) edges[i] = new int[degree[i]];
        Arrays.fill(degree, 0);
        for (int i = 0; i < w.count(); i++) {
            edges[w.a()[i]][degree[w.a()[i]]++] = i;
            edges[w.b()[i]][degree[w.b()[i]]++] = i;
        }
        boolean[] visited = new boolean[n];
        PriorityQueue<Integer> queue = new PriorityQueue<>(Comparator.comparingInt(i -> w.cost()[i]));
        long total = 0;
        for (int start = 0; start < n; start++) {
            if (visited[start]) continue;
            visited[start] = true;
            for (int edge : edges[start]) queue.add(edge);
            while (!queue.isEmpty()) {
                int edge = queue.remove();
                int a = w.a()[edge], b = w.b()[edge];
                if (visited[a] && visited[b]) continue;
                int next = visited[a] ? b : a;
                visited[next] = true;
                total += w.cost()[edge];
                for (int e : edges[next]) {
                    if (!visited[w.a()[e]] || !visited[w.b()[e]]) queue.add(e);
                }
            }
        }
        return total;
    }
}
