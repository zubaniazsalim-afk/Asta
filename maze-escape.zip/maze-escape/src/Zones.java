import java.util.*;

public class Zones {
    public static int[] kosaraju(Input.Slides s) {
        int n = s.n();
        int[][] from = Graphs.slidesFrom(s);
        int[][] into = Graphs.slidesInto(s);
        boolean[] visited = new boolean[n];
        int[] stack = new int[n];
        int[] nextEdge = new int[n];
        int[] finish = new int[n];
        int count = 0;
        for (int start = 0; start < n; start++) {
            if (visited[start]) continue;
            int top = 0;
            stack[0] = start;
            visited[start] = true;
            while (top >= 0) {
                int cell = stack[top];
                if (nextEdge[cell] == from[cell].length) {
                    finish[count++] = cell;
                    top--;
                } else {
                    int edge = from[cell][nextEdge[cell]++];
                    int next = s.to()[edge];
                    if (!visited[next]) {
                        visited[next] = true;
                        stack[++top] = next;
                    }
                }
            }
        }
        int[] zone = new int[n];
        Arrays.fill(zone, -1);
        int zoneCount = 0;
        for (int i = n - 1; i >= 0; i--) {
            int start = finish[i];
            if (zone[start] != -1) continue;
            int top = 0;
            stack[0] = start;
            zone[start] = zoneCount;
            while (top >= 0) {
                int cell = stack[top--];
                for (int edge : into[cell]) {
                    int next = s.from()[edge];
                    if (zone[next] == -1) {
                        zone[next] = zoneCount;
                        stack[++top] = next;
                    }
                }
            }
            zoneCount++;
        }
        return zone;
    }

    public static long[] routes(Input.Slides s, int[] zoneOf, int zoneCount) {
        int[] degree = new int[zoneCount];
        for (int i = 0; i < s.count(); i++) {
            if (zoneOf[s.from()[i]] != zoneOf[s.to()[i]]) degree[zoneOf[s.from()[i]]]++;
        }
        int[][] edges = new int[zoneCount][];
        for (int z = 0; z < zoneCount; z++) edges[z] = new int[degree[z]];
        Arrays.fill(degree, 0);
        for (int i = 0; i < s.count(); i++) {
            int a = zoneOf[s.from()[i]], b = zoneOf[s.to()[i]];
            if (a != b) edges[a][degree[a]++] = i;
        }
        long[] distance = new long[zoneCount];
        Arrays.fill(distance, Long.MAX_VALUE);
        distance[zoneOf[0]] = 0;
        int[] stages = new int[zoneCount];
        Arrays.fill(stages, 1);
        long longest = 0;
        for (int z = 0; z < zoneCount; z++) {
            longest = Math.max(longest, stages[z]);
            for (int edge : edges[z]) {
                int next = zoneOf[s.to()[edge]];
                stages[next] = Math.max(stages[next], stages[z] + 1);
                if (distance[z] != Long.MAX_VALUE) {
                    distance[next] = Math.min(distance[next], distance[z] + s.time()[edge]);
                }
            }
        }
        return new long[]{longest, distance[zoneOf[s.n() - 1]]};
    }
}
